function output = percHeight(coef)
% estimate the normalized time after which an attribute has reached a
% certaion proportion of its full height
%
% written 2014 by:
% nikki sullivan, nsullivan@caltech.edu
% www.its.caltech.edu/~nsulliva

nRegs = size(coef,3);
subjects = 1:size(coef,2);


%% antonio method

percents = 0:.01:1;
percentsSq = percents.^2;
percentsCub = percents.^3;

timeP = NaN(length(percents),2,length(subjects));
intercept = NaN(2,length(subjects));
yPredict = NaN(length(percents)+2,2,length(subjects));

for subj = 1:length(subjects)
    for nR = 1:nRegs

        if nRegs> 1
            theseCoef = coef(:,subj,nR);
        else
            theseCoef = coef(:,subj);
        end
        
        % find time at which reach a certain percent
        for p = 1:length(percents)
            target = percents(p) * theseCoef(end); % x percent of final coef.
            
            aboveTarget = (target > 0 & theseCoef >= target) | ...
                (target < 0 & theseCoef <= target);
            
            % if all in this time period are above target:
            timeP(p,nR,subj) = find(~aboveTarget,1,'last')+1;
            
        end
        timeP(timeP==102) = NaN; % never above target.
        
        % fit model
        if any(~isnan(timeP(:,nR,subj)))
            
            stats = regstats(timeP(:,nR,subj), ...
                [percents' percentsSq' percentsCub']);
            intercept(nR,subj) = stats.beta(1);
            yPredict(:,nR,subj) = stats.beta(1) + ...
                stats.beta(2).*[0 percents 1]' + stats.beta(3).*[0 percentsSq 1]' + ...
                stats.beta(4).*[0 percentsCub 1]';
            
        end
        
    end
    output.timePDiffAUC(subj) = sum(timeP(:,2,subj) - timeP(:,1,subj));
    output.yPredictDiffAUC(subj) = sum(yPredict(:,2,subj) - yPredict(:,1,subj));
end
output.interDiff = intercept(1,:)-intercept(2,:);
output.intercept = intercept;
output.timeP = timeP;
output.percents = percents;
output.yPredict = yPredict;


end