function output=mediationAnalysis(coef,sigTimeUse,successratio,fileID)
% when mediator & IV used simultaneously to predict DV, 
% the previously significant path b/n the IV & DV (Step #1) 
% is now greatly reduced, if not nonsignificant.
%
% written 2014 by:
% nikki sullivan, nsullivan@caltech.edu
% www.its.caltech.edu/~nsulliva

%% Baron Kennedy

if ~exist('sigTimeUse','var')
    disp('no ST var specified.')
    sigTimeUse = sigTime.tastehealth.bysubj;
    sigTimeUse(isnan(sigTimeUse)) = 102;
end
if ~exist('fileID')
    fileID=fopen('/group_data/med.txt','w');
    closeLater=true;
else
    closeLater=false;
end
IVName='ST';
DVName='SCSR';
MedName='Final Coef.';

IVTypes = {'Taste','Health'};
IVind = [1,2];

for nIV = 1:length(IVTypes)
    % get data
    IV = sigTimeUse(:,IVind(nIV));
    DV = successratio';
    med = coef.tastehealth(end,:,IVind(nIV))';
    
    % 1. IV predicts DV?
    stats = regstats(DV,IV);
    stepOne=[stats.beta(2) stats.tstat.pval(2)];
    % 2. mediator predicted by IV?
    stats = regstats(med,IV);
    stepTwo=[stats.beta(2) stats.tstat.pval(2)];
        % 2b. mediator predicts DV? (incidental for med. analysis, but use in figure)
        stats = regstats(DV,med);
        stepTwoB=[stats.beta(2) stats.tstat.pval(2)];
    % 3. both in predictor model
    stats = regstats(DV,[IV med]);
    stepThree = [stats.beta(2:3) stats.tstat.pval(2:3)]; %[betas column, p column]
    % 4. percent change in path strength:
    changePathStrngth=(abs(stepOne(1)) - abs(stepThree(1,1))) / abs(stepOne(1)); 
    fprintf(fileID,'----------- %s mediation analysis -----------\n\r',...
        IVTypes{nIV});
    fprintf(fileID,'IV (%s) -> DV (%s) strength: %0.4f, p=%0.4f\n\r',IVName,DVName,...
        stepOne(1),stepOne(2));
    fprintf(fileID,'IV (%s) -> Med (%s) strength: %0.4f, p=%0.4f\n\r',IVName,MedName,...
        stepTwo(1),stepTwo(2));
    fprintf(fileID,'Med (%s) -> DV (%s) strength: %0.4f, p=%0.4f\n\r',MedName,DVName,...
        stepTwoB(1),stepTwoB(2));
    fprintf(fileID,'IV (%s) & Med (%s) -> DV (%s): IV strength: %0.4f, p=%0.4f\n\r',...
        IVName, MedName,DVName,stepThree(1,1),stepThree(1,2));
    fprintf(fileID,'percent change in path strength: %0.04f%% \n\r',changePathStrngth*100);
    fprintf(fileID,'---------------------- Summary: ----------------------\n\r');
    IV_beta_reduced = abs(stepOne(1)) > abs(stepThree(1,1)); % IV beta reduced?
    if IV_beta_reduced
        fprintf(fileID,['IV beta (' IVName ') is reduced.\n']);
    else
        fprintf(fileID,['IV beta (' IVName ') is not reduced.\n']);
    end
    if stepThree(1,2)<.05
        fprintf(fileID,'IV p-value still significant (p=%0.03f)\n',stepThree(1,2));
    else
        fprintf(fileID,'IV p-value not still significant (p=%0.03f)\n\n\r',stepThree(1,2));
    end
    output.(IVTypes{nIV}).percChange = changePathStrngth*100;
    output.(IVTypes{nIV}).pVal = stepThree(1,2);
end

%% close file if necessary
if closeLater
    fclose(fileID);
    clear fileID
end

end