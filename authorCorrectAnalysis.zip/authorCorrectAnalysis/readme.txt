Corrected Analysis Code for Sullivan et al., 2015
-------------------------------------------------------------------------------
This OSF component contains a corrected version of the data and scripts to reproduce analyses from Sullivan et al. 2015 (doi: 10.1177/0956797614559543).

Reasons for the correction:
1) The "Example analysis code" component uploaded to OSF 10/17/2014 (https://osf.io/7gvh9/) was not sufficiently documented and hard to use in replicating the published results. The code presented here is a commented version of the code used to produce the reported analyses, and therefore identically replications the results from the paper.
2) The data file with the mouse traces (sullivanEtAl2014ForPub_mouse.csv) contained several errors, leading to another source of discrepancy from the paper's reported statistics. The mouse tracking data uploaded in this component (newData.csv) is the original raw data.
3) This code reports that the percent of trials excluded from analysis is 8.1%, but the paper reports that it was 13.3%. This updated 8.1% figure is correct, and the reported number in the paper is a mistake.

How to run
1) To get started, put all scripts and files from this component into the same directory. 
2) Run MATLAB script updatedCode.m from that directory. This will replicate the statistics (output to the MATLAB desktop window) and plots (as separate figures) from the paper.
NOTE: Figure 4b's histogram was generated using R, so will look slightly different


Details on the files in this component
-------------------------------------------------------------------------------
Main analysis script
updatedCode.m: Replicates all statistics and figures as reported in the paper

Data files
newData.csv: mouse tracking condition data file
sullivanEtAl2014ForPub_key.csv: keyboard condition data file

Helper files called by updatedCode.m
timepoint_regressions.m: Performs the timepoint regression for each subject, determining when the taste and health ratings become significant.
percHeight.m: Calculates a corrected version of when the taste/health ratings become significant.
plotTwoDimError.m: Plots two dimensional data with an error area using both dimension’s error bars and helps with figure generation. 
shadedErrorBar.m: Helper function to create nice looking error bars. Created by Rob Campbell, 2009 (https://www.mathworks.com/matlabcentral/fileexchange/26311-raacampbell-shadederrorbar)
mediationAnalysis.m: Performs the mediation analysis described in the paper. Produces output in the mediation.txt file, giving a summary of the results.

Code is confirmed to run in Matlab 2017b - 7/2018


Contact
-------------------------------------------------------------------------------
Nikki Sullivan, njs28@duke.edu

