function [coef sigTime pval] = timepoint_regressions(nTPs,angleDirect,exclude, like,taste,health,successratio)
% estimate the influence of an attribute on the mouse cursor
%
% written 2013 by:
% nikki sullivan, nsullivan@caltech.edu
% www.its.caltech.edu/~nsulliva


%% set-up

subjects=1:28;

% index for better and worse self controllers
controlInd{1} = successratio>nanmean(successratio);
controlInd{2} = successratio<nanmean(successratio);
% for all subjects, for better and worse SC
psnTypes = {'all','betterSC','worseSC'};
indTypes = [true(1,length(subjects)); controlInd{1}; controlInd{2}];


%% -- perform regressions

minTrials = 30; % minimum trials req'd for regression

coef.liking = NaN(101,length(subjects));
pval.liking = NaN(101,length(subjects));
coef.tastehealth = NaN(101,length(subjects),2);
pval.tastehealth = NaN(101,length(subjects),2);
coef.tastehealthTtest = NaN(101,length(subjects)); % this is really a t-stat
pval.tastehealthTtest = NaN(101,length(subjects));

for subj = 1:length(subjects)
    
    % regressors:
    likingratingsdiff.all = like(:,2,subj)-like(:,1,subj);
    tastehealthdiff.all = [taste(:,2,subj)-taste(:,1,subj) ... %l taste
        health(:,2,subj)-health(:,1,subj)];% l health

    % regression
    for t = 1:size(angleDirect{subj},1) % for each time point from t=1 to t=end
        if nansum(~isnan(angleDirect{subj}(t,~exclude(:,subj)))) > minTrials
            % liking            
            nT=length(likingratingsdiff.all);
            temp = regstats(angleDirect{subj}(t,~exclude(1:nT,subj))',...
                likingratingsdiff.all(~exclude(1:nT,subj)),'linear',{'tstat'});
            coef.liking(t,subj) = temp.tstat.beta(2);
            pval.liking(t,subj) = temp.tstat.pval(2);
            temp = regstats(angleDirect{subj}(t,~exclude(1:nT,subj))',...
                tastehealthdiff.all(~exclude(1:nT,subj),:),'linear',{'tstat','covb','beta'});
            coef.tastehealth(t,subj,1:2) = temp.tstat.beta(2:3);
            pval.tastehealth(t,subj,1:2) = temp.tstat.pval(2:3);
        end

    end

end

% turn Inf outcomes to NaNs.
coef.liking(~isfinite(coef.liking) | ~isfinite(pval.liking))=NaN;
coef.tastehealth(~isfinite(coef.tastehealth) | ~isfinite(pval.tastehealth))=NaN;




%% last time point for each array calculations
types={'liking','tastehealth'};
nReg=[1,2];
for nT = 1:length(types)
    for nR = 1:nReg(nT)

        for subj = 1:length(subjects)        
            last_timepoint.(types{nT}).all(subj,nR) = find(~isnan(coef.(types{nT})(:,subj,nR))==1,1,'last'); %101;
        end

        lastTimeWithPower.(types{nT})(nR) = min(last_timepoint.(types{nT}).all(:,nR));%101;
    end
end

%% significance time per-subject
% Significance Time: How long it takes to reach a significant 
    % coefficient that does later return to being not significant.

regTypes = {'liking','tastehealth'};
regTypesnR = [1,2];

% one or two tailed ttest?
tails=1;
if tails==2
    for nT = 1:length(regTypes)
        test.(regTypes{nT}) = pval.(regTypes{nT}) < .05;
    end
elseif tails==1
    for nT = 1:length(regTypes)
        test.(regTypes{nT}) = pval.(regTypes{nT})./2 < .05;
    end
end

for nT = 1:length(regTypes)
    sigTime.(regTypes{nT}).bysubj = NaN(length(subjects),regTypesnR(nT));
end

velocThresh = 10; % must have >= 10 tps sig in a row for ST

for subj = 1:length(subjects)
    for nT = 1:length(regTypes) % for each regression type (liking, taste/health)
        for nR = 1:regTypesnR(nT) % for each coef. in regression
            
            thisTest = test.(regTypes{nT})(:,subj,nR);
            
            % find cut-offs, detect if there's a ST
            cutOff = last_timepoint.(regTypes{nT}).all(subj,nR);
            hasST = find(thisTest(1:cutOff)==1,1,'last') ...
                == last_timepoint.(regTypes{nT}).all(subj);

            % calculate ST
            if hasST
                sigTime.(regTypes{nT}).bysubj(subj,nR) = 1 + ...
                    find(thisTest(1:cutOff)==0,1,'last');
            end
            
        end
    end
end

%% ST for mean data


for nT = 1:length(regTypes) % for each regression type (liking, taste/health)
    for nR = 1:regTypesnR(nT) % for each coef. in regression
        for nP = 1:length(psnTypes)
        
            cutOff = lastTimeWithPower.(regTypes{nT})(nR);

            % t-test
            if tails==2
                thisTest = ttest(...
                    coef.(regTypes{nT})(1:cutOff,indTypes(nP,:),nR)',0,.05)';
            elseif tails==1
                thisTest = ttest(...
                    coef.(regTypes{nT})(1:cutOff,indTypes(nP,:),nR)',0,.05,'right')';
            end

            if nansum(thisTest(1:cutOff)) == cutOff
                sigTime.(regTypes{nT}).(psnTypes{nP})(nR) = 2;
            else
                sigTime.(regTypes{nT}).(psnTypes{nP})(nR) = 1 + ...
                    find(thisTest(1:cutOff)==0,1,'last');
            end
            if sigTime.(regTypes{nT}).(psnTypes{nP})(nR) > 101
                sigTime.(regTypes{nT}).(psnTypes{nP})(nR) = NaN;
            end

        end        
    end
end


end % function