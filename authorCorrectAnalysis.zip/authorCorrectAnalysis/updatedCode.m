function updatedCode
% this code will replicate results from Sullivan, N. J., Hutcherson, C. A., 
% Harris, A., Rangel, A. Dietary self-control is related to the speed with which 
% health and taste attributes are processed. Psychological Science. 2015
%
% written 6/2018 by Nikki Sullivan

%% plot settings
fNo=1;
fontsize=14;

%% ------------------------------------------------------------------------
% load and format data
% -------------------------------------------------------------------------

% x, y dimensions of computer screen:
screenDims = [1680 1050];
cursorStartPixels = [840 840]; % screen convention in which larger y-coordinates are lower on the screen
subjects=1:28;

% get mouse data
% columns in the csv file:
% [subject | time point | x-position (pixels) | y-position (pixels) | 
% liking rating (left) | liking rating (right) | 
% taste rating (left) | taste rating (right) | 
% health rating (left) | health rating (right) |choice (1==left) | RT | 
% mouse position timestamps | time until first mouse movement | 
% time between start button click and mouse re-appearing |
% time stamp for start button display]
data=csvread('newData.csv');
nTPs = NaN(240,28);
xPos = NaN(240,8500,28);
yPos = NaN(240,8500,28);
xPosUncorr = NaN(240,8500,28);
yPosUnCorr = NaN(240,8500,28);
like = NaN(240,2,28);
taste = NaN(240,2,28);
health = NaN(240,2,28);
choice = NaN(240,28);
RT = NaN(240,28);
healthChosen = NaN(240,28);
healthUnchosen = NaN(240,28);
timeStamp = NaN(240,8500,28);
moveTime = NaN(240,28);
blankScreenTime = NaN(240,28);
startScreenOnTimeStamp = NaN(240,28);
unchosen=[2 1];
for subj = 1:28
    % find this subject
    thisSubjData = data(data(:,1)==subj,:);
    
    % find each trial
    trialStarts = find(thisSubjData(:,2)==1);
    trialEnds = [trialStarts(2:end)-1; length(thisSubjData)]; 
    
    % separate data by trial
    for trial = 1:length(trialStarts)
        nTPs(trial,subj) = (1+trialEnds(trial)) - trialStarts(trial);
        
        xPos(trial,1:nTPs(trial,subj),subj) = thisSubjData(trialStarts(trial):trialEnds(trial),3);
        yPos(trial,1:nTPs(trial,subj),subj) = thisSubjData(trialStarts(trial):trialEnds(trial),4);
        % in original code, x and y starting positions re-set to origin to
        % account for sampling error
        xPosUncorr(trial,1:nTPs(trial,subj),subj) = xPos(trial,1:nTPs(trial,subj),subj);
        yPosUnCorr(trial,1:nTPs(trial,subj),subj) = yPos(trial,1:nTPs(trial,subj),subj);
        xPos(trial,1,subj) = 840;
        yPos(trial,1,subj) = 210;
        
        % stimulus info
        like(trial,:,subj) = thisSubjData(trialStarts(trial),5:6);
        taste(trial,:,subj) = thisSubjData(trialStarts(trial),7:8);
        health(trial,:,subj) = thisSubjData(trialStarts(trial),9:10);
        
        % choice info
        choice(trial,subj) = thisSubjData(trialStarts(trial),11);
        RT(trial,subj) = thisSubjData(trialStarts(trial),12);
        
        % mouse tracking timing info
        % time stamps for mouse sample collection
        timeStamp(trial,1:nTPs(trial,subj),subj) = thisSubjData(trialStarts(trial):trialEnds(trial),13);
        % time subj took for first mouse movement
        moveTime(trial,subj) = thisSubjData(trialStarts(trial),14);
        % time between start button click and mouse re-appearing
        blankScreenTime(trial,subj) = thisSubjData(trialStarts(trial),15);
        % time stamp for start button display
        startScreenOnTimeStamp(trial,subj) = thisSubjData(trialStarts(trial),16);

        healthChosen(trial,subj) = health(trial,choice(trial,subj),subj);
        healthUnchosen(trial,subj) = health(trial,unchosen(choice(trial,subj)),subj);
    end
    
end

% get keyboard data
% columns:
% [subject |  
% liking rating (left) | liking rating (right) | 
% taste rating (left) | taste rating (right) | 
% health rating (left) | health rating (right) | choice | RT ]
data=csvread('sullivanEtAl2014ForPub_key.csv');
key_like = NaN(80,2,28);
key_taste = NaN(80,2,28);
key_health = NaN(80,2,28);
key_healthChosen = NaN(80,28);
key_healthUnchosen = NaN(80,28);
key_choice = NaN(80,28);
key_RT = NaN(80,28);
for subj = 1:28
    % find this subject
    thisSubjData = data(data(:,1)==subj,:);
    nTrials = length(thisSubjData);
    
    key_like(1:nTrials,1:2,subj) = thisSubjData(:,2:3);
    key_taste(1:nTrials,1:2,subj) = thisSubjData(:,4:5);
    key_health(1:nTrials,1:2,subj) = thisSubjData(:,6:7);
    key_choice(1:nTrials,subj) = thisSubjData(:,8);
    key_RT(1:nTrials,subj) = thisSubjData(:,9);
    
    for trial = 1:nTrials
        key_healthChosen(trial,subj) = key_health(trial,key_choice(trial,subj),subj);
        key_healthUnchosen(trial,subj) = key_health(trial,unchosen(key_choice(trial,subj)),subj);
    end
end



%% ------------------------------------------------------------------------
% process mouse trace data and transform
% -------------------------------------------------------------------------

spat = cell(28,1);
spatDirect = cell(28,1);
temporal = cell(28,1);
temporalDirect = cell(28,1);
spatInterp = cell(28,1);
angleDirect = cell(28,1);
nTrials = NaN(28,1);

for subj = 1:28 % subject
    spat{subj} = NaN(8500,2,240);
    spatDirect{subj} = NaN(8500,2,240);
    temporal{subj} = NaN(101,2,240);
    temporalDirect{subj} = NaN(101,2,240);
    spatInterp{subj} = NaN(101,2,240);
    angleDirect{subj} = NaN(101,240);
    for trial = find(~isnan(choice(:,subj)))' % trial
        
        % spatial remapping: rescale from pixels to standard coord. space
        % convert all clicks to right-hand side - end is all (1,1)
        spat{subj}(1:nTPs(trial,subj),1,trial) = ...
            (xPos(trial,1:nTPs(trial,subj),subj) - xPos(trial,1,subj)) ...
            / (xPos(trial,nTPs(trial,subj),subj) - xPos(trial,1,subj));
        spat{subj}(1:nTPs(trial,subj),2,trial) = ...
            (yPos(trial,1:nTPs(trial,subj),subj) - yPos(trial,1,subj)) ...
            / (yPos(trial,nTPs(trial,subj),subj) - yPos(trial,1,subj));
        % retain choice - end is (-1,1) or (1,1)
        spatDirect{subj}(:,1,trial) = spat{subj}(:,1,trial) * sign(choice(trial,subj)-2+.5);
        spatDirect{subj}(:,2,trial) = spat{subj}(:,2,trial);

        % linear temporal{subj} interpolation (101 timepoints)
        if timeStamp(trial,1,subj) ~= 0 % then time stamps were collected.
            % time each cursor position sample was acquired (zeroed):
            ptOne = moveTime(trial,subj) + blankScreenTime(trial,subj) ...
                + startScreenOnTimeStamp(trial,subj);
            timeStamps = [ptOne; ...
                timeStamp(trial,2:nTPs(trial,subj),subj)'] - ptOne;
        else
            % if no timestamps collected, assume equally-spaced sampling
            timeStamps = (1:nTPs(trial,subj))';
        end
        % change original sampling to linearly-interpolated sampling:
        timeSamples = linspace(timeStamps(1),timeStamps(end),101);
        % convert all clicks to right-hand side - end is all (1,1)
        temporal{subj}(:,1,trial) = ...
            interp1(timeStamps,... % timepoints
            spat{subj}(1:nTPs(trial,subj),1,trial),... % coordinate
            timeSamples,... % timepoints to use for interploating
            'linear');
        temporal{subj}(:,2,trial) = interp1(timeStamps, ...
            spat{subj}(1:nTPs(trial,subj),2,trial),timeSamples,'linear');
        % retain choice - end is (-1,1) or (1,1)
        temporalDirect{subj}(:,1,trial) = ...
            interp1(timeStamps,spatDirect{subj}(1:nTPs(trial,subj),1,trial), ...
            timeSamples,'linear');
        temporalDirect{subj}(:,2,trial) = ...
            interp1(timeStamps,spatDirect{subj}(1:nTPs(trial,subj),2,trial), ...
            timeSamples,'linear');


        % temporal interpolation of trajectories with pixel info (for fig. 2C)
        spatInterp{subj}(:,1,trial) = ...        
            interp1(timeStamps,xPos(trial,1:nTPs(trial,subj),subj), ...
            timeSamples,'linear');
        spatInterp{subj}(:,2,trial) = ...
            interp1(timeStamps,yPos(trial,1:nTPs(trial,subj),subj), ...
            timeSamples,'linear');

        
        % angle
        angleDirect{subj}(:,trial) = ...
            abs(atand(temporalDirect{subj}(:,1,trial) ./ ...
            temporalDirect{subj}(:,2,trial))) .* ...
            sign(temporalDirect{subj}(:,1,trial));
        % optional: exclude time points where mouse moving downward
        excludeInd = [false; temporalDirect{subj}(2:end,2,trial) < ...
            temporalDirect{subj}(1:end-1,2,trial)];
        angleDirect{subj}(excludeInd,trial) = NaN;
        
    end
    nTrials(subj) = find(~isnan(squeeze(temporal{subj}(1,1,:))),1,'last');
end


%% ------------------------------------------------------------------------
% mouse trace trial exclusions
% -------------------------------------------------------------------------

exclude = false(240,28);
reason.yCross =  false(240,28);
reason.twoSD =  false(240,28);
reason.overshoot =  false(240,28);
reason.undershoot =  false(240,28);
for subj = 1:28 % subject
    
    
    for trial = 1:nTrials(subj) % trial
        
        % how many times does cursor cross y axis? exclude if > 3
        ycross=0;
        for t=2:nTPs(trial,subj)
            if (roundn(xPosUncorr(trial,t,subj),1) < cursorStartPixels(1) && roundn(xPosUncorr(trial,t-1,subj),1) >= cursorStartPixels(1)) ...
                || (roundn(xPosUncorr(trial,t,subj),1) > cursorStartPixels(1) && roundn(xPosUncorr(trial,t-1,subj),1) <= cursorStartPixels(1))
                ycross = ycross+1;
            end
        end
        if ycross <= 3 && nTPs(trial, subj) > 20
            reason.yCross(trial, subj) = false;
        else
            reason.yCross(trial, subj) = true;
        end

   end
   exclude(reason.yCross(:,subj), subj) = true;
    

    % exclude b/c RT > 2 SD above mean
    % in calculating standard deviation, don't include trials where RT > 5 min b/c that's a mistake or question they're asking (i.e. they're not doing the task).
    ind = ~exclude(:,subj) & nTPs(:,subj) <= 500;
    rtData = nTPs(ind,subj);
    twoSD = nanstd(rtData)*2;
    ave = nanmean(rtData);
    reason.twoSD(:,subj) = nTPs(:,subj) > ave+twoSD;
    exclude(reason.twoSD(:,subj),subj) = true;
    

    % optional: exclude "overshoots" (times where the cursor goes far past food box before clicking)
    for trial = 1:nTrials(subj) % trial
        if sum(spatDirect{subj}(1:nTPs(trial,subj),1,trial) > 1.3) > 0 % ... it's an overshoot 
            reason.overshoot(trial,subj) = true;
        end
        if sum(spatDirect{subj}(1:nTPs(trial,subj),1,trial) <= -1.3) > 0 % or if it's too close to unselected food
            reason.undershoot(trial,subj) = true;
        end
    end
    exclude(reason.overshoot(:,subj), subj) = true;
    exclude(reason.undershoot(:,subj), subj) = true;



    % now remove those trials from the data:
    angleDirect{subj}(:,exclude(:,subj)) = NaN;
end




%% ------------------------------------------------------------------------
% paper reported statistics
% -------------------------------------------------------------------------

%% calculate self-control success ratio (SCSR) and RT averages
successratio = zeros(1,28);
for subj = 1:28
    
    % classification uses both mouse and key trials:
    allHealth = [health(:,:,subj); key_health(:,:,subj)];
    allTaste = [taste(:,:,subj); key_taste(:,:,subj)];
    allHealthChosen = [healthChosen(:,subj); key_healthChosen(:,subj)];
    allHealthUnchosen = [healthUnchosen(:,subj); key_healthUnchosen(:,subj)];
    
    % challenge trial: trials requiring self control 
    % false = control not required. true=control required
    challengeTrial = ...
        ((allHealth(:,1) > allHealth(:,2)) & ...
        (allTaste(:,1) < allTaste(:,2))) | ...
        ((allHealth(:,2) > allHealth(:,1)) & ...
        (allTaste(:,2) < allTaste(:,1)));
    
    % healthier food chosen = true, otherwise false
    successTrial = challengeTrial & allHealthChosen > allHealthUnchosen;
    
    % ratio
    successratio(subj) = sum(successTrial)/sum(challengeTrial);    

end

% split participants by SCSR
controlInd{1} = successratio > nanmean(successratio);
controlInd{2} = successratio < nanmean(successratio);


%% time course regressions

% cursor influence and significance time
[coef,sigTimes] = ...
    timepoint_regressions(nTPs,angleDirect,exclude,like,taste,...
    health,successratio);
% corrected measure
correctST = percHeight(coef.tastehealth);


%% methods, data preprocessing section

twoSD_RTsum = [];
for subj = 1:length(subjects)
     longRT(subj) = sum(RT(:,subj) > 2.5) ./ ...
         nTrials(subj);
     twoSD_RT(subj) = sum(reason.twoSD(:,subj)) ./ ...
         nTrials(subj);
     yCrossNotPrevExcluded(subj) = ...
         sum(reason.yCross(RT(:,subj) < 2.5,subj)) ./ nTrials(subj);
end
sum(sum(reason.twoSD)) ./ sum(nTrials)
% what was reported in the paper: (paper has correct method, wrong statistic)
fprintf('Response time greater than 2500 ms: %0.0f%%\n',...
    mean(longRT)*100)
% maybe what we did instead?? (correct statistic)
fprintf(['mouse trials with reaction times (RTs) greater than two standard '...
    'deviations above their mouse-trial mean: %0.0f%%\n'], nanmean(twoSD_RT)*100)

fprintf('Ave. percent of trials excluded for y-cross: %0.0f%%\n',...
    mean(yCrossNotPrevExcluded)*100)
fprintf('mean RT %0.0f ms, SD %0.0f\n',nanmean(nanmean(RT.*1000)),...
    nanstd(nanmean(RT.*1000)))



%% "Paradigm validation" section statistics

% psychometric curve
for subj = 1:28
    
    % mouse tracking trials
    leftChoice = choice(:,subj)==1;
    diffL = like(:,1,subj) - like(:,2,subj);
    total_foods = [sum(diffL==-4); sum(diffL==-3); sum(diffL==-2); ...
        sum(diffL==-1); sum(diffL==0); sum(diffL==1); sum(diffL==2); ...
        sum(diffL==3); sum(diffL==4)];
    left_choice = [sum(diffL==-4 & leftChoice); ...
        sum(diffL==-3 & leftChoice); ...
        sum(diffL==-2 & leftChoice); ...
        sum(diffL==-1 & leftChoice); ...
        sum(diffL==0 & leftChoice); ...
        sum(diffL==1 & leftChoice); ...
        sum(diffL==2 & leftChoice); ...
        sum(diffL==3 & leftChoice); ...
        sum(diffL==4 & leftChoice)];
    prob_left_m(:,subj) =  left_choice ./ total_foods;
    % individual logits:
    b = mnrfit(diffL,[ones(length(leftChoice),1), leftChoice]);
    likeBeta.mouse(subj) = b(2);
    
    % keyboard trials
    leftChoice = key_choice(:,subj)==1;
    diffL = key_like(:,1,subj) - key_like(:,2,subj);
    total_foods = [sum(diffL==-4); sum(diffL==-3); sum(diffL==-2); ...
        sum(diffL==-1); sum(diffL==0); sum(diffL==1); sum(diffL==2); ...
        sum(diffL==3); sum(diffL==4)];
    left_choice = [sum(diffL==-4 & leftChoice); ...
        sum(diffL==-3 & leftChoice); ...
        sum(diffL==-2 & leftChoice); ...
        sum(diffL==-1 & leftChoice); ...
        sum(diffL==0 & leftChoice); ...
        sum(diffL==1 & leftChoice); ...
        sum(diffL==2 & leftChoice); ...
        sum(diffL==3 & leftChoice); ...
        sum(diffL==4 & leftChoice)];
    prob_left_k(:,subj) = left_choice ./ total_foods;    
    % individual logits:
    b = mnrfit(diffL,[ones(length(leftChoice),1), leftChoice]);
    likeBeta.key(subj) = b(2);

end
predictorArray = [];
outcomeArray = [];outcomeArray_m = [];outcomeArray_k = [];
for subj=1:28
    predictorArray = [predictorArray; (-4:4)'];
    outcomeArray_m = [outcomeArray_m; prob_left_m(:,subj)];
    outcomeArray_k = [outcomeArray_k; prob_left_k(:,subj)];
end
% non-linear regression fit:
modelfun = @(b,x)(1 ./ (1+exp(b(1) * x)));
beta0 = 1;
b_left_m = nlinfit(predictorArray,outcomeArray_m,modelfun,beta0);
b_left_k = nlinfit(predictorArray,outcomeArray_k,modelfun,beta0);
% % reported in paper:
% ['We found that the two methods of choosing led to'...
% 'indistinguishable choice curves (mouse: mean logistic'...
% 'slope = -0.37; keyboard: mean logistic slope = -0.33),'...
% 't(27) = 1.25, p = .22 (two-tailed).']
% choice curve
[~,p,~,stats]=ttest(likeBeta.mouse,likeBeta.key);
sprintf(['We found that the two cases led to indistinguishable choice '...
    'curves (mean\nlogistic slope mouse = %0.2f, mean logistic slope '...
    'keyboard = %0.2f;\np=%0.2f), t(%0.0f)=%0.2f (two-tailed).'], ...
    nanmean(likeBeta.mouse),nanmean(likeBeta.key),p,stats.df,stats.tstat)


% response time curve
mouse_ABS=NaN(5,28);
keyboard_ABS=NaN(5,28);
for subj = 1:28
    
    diff = abs(like(:,1,subj) - like(:,2,subj));
    key_diff = abs(key_like(:,1,subj) - key_like(:,2,subj));
    
    diffArray = 0:4;
    for d=1:length(diffArray)
        mouse_ABS(d,subj) = nanmean(RT(diff==diffArray(d) & ~exclude(:,subj), subj));
        if subj ~=21 || (subj == 21 && diffArray(d) ~= 4)% to exclude crazy outlier
            keyboard_ABS(d,subj) = nanmean(key_RT(key_diff==diffArray(d),subj));
        end
    end
    
    % mouse: regressions
    temp = regstats(RT(~exclude(:,subj),subj), diff(~exclude(:,subj)), 'linear');
    RT_mouse_linreg(subj) = temp.beta(2);
    
    % key:
    temp = regstats(key_RT(key_RT(:,subj)<=2.5,subj), ...
        key_diff(key_RT(:,subj)<=2.5), 'linear');
    RT_key_linreg(subj) = temp.beta(2);
    
end
% % reported in paper:
% ['RTs were longer in the mouse condition (M ='...
% '1,814 ms) than in the keyboard condition (M = 1,258 ms),'...
% 't(27) = 4.54, p = .0001 (two-tailed),']
[~,p,~,stats]=ttest(nanmean(RT),nanmean(key_RT));
sprintf(['RTs were longer in the mouse condition (mean = %0.0f ms) than '...
    'in the keyboard\ncondition (M = %0.0f ms), t(%0.0f)=%0.2f, p=%0.4f '...
    '(two-tailed)'],nanmean(nanmean(RT*1000)), nanmean(nanmean(key_RT*1000)),...
    stats.df, stats.tstat, p)
% % reported in paper:
% ['However, in both cases, RTs decreased with choice difficulty'...
% '(mouse: mean linear regression slope = -0.036; keyboard:'...
% 'mean linear regression slope = -0.051), t(27) ='...
% '-1.36, p = .18 (two-tailed).']
[~,p,~,stats]=ttest(RT_mouse_linreg,RT_key_linreg);
sprintf(['the absolute value of the liking rating differences (mouse mean '...
    'linear regression\nslope = %0.03f; keyboard mean linear regression '...
    'slope = %0.3f;\np=%0.2f, t(%0.0f)=%0.2f, two-tailed).'],...
    nanmean(RT_mouse_linreg), nanmean(RT_key_linreg), p, stats.df, stats.tstat)
 

% reported in paper:
% ['We found that, across subjects, the earliest time'...
% 'point at which the value information had a sustained,'...
% 'significant effect on the trajectories, without ever returning'...
% 'to being nonsignificant, was 56.']
sprintf(['We found that, across the group, the earliest time at which the '...
'value information had a sustained, significant, effect on the '...
'trajectories, without ever returning to being not-significant, for the '...
'group was t = %0.0f.'],sigTimes.liking.all)

% % reported in paper:
% ['Figure 3d, which depicts the distribution of SCSRs'...
% 'across subjects, shows that there was substantial variation'...
% 'across subjects (M = 25%, range = 2�78%). There were no'...
% 'significant RT differences between challenge trials (M ='...
% '1,782 ms) and nonchallenge trials (M = 1,701 ms), t(27) ='...
% '0.78, p = .44 (two-tailed), which is consistent with the'...
% 'hypothesis that subjects utilized a similar decision process'...
% 'in both types of trials.']
% dietary self-control success ratio (SCSR)
sprintf(['Figure 3d, which depicts the distribution of SCSRs across the group, and shows that there was substantial '...
    'variation across subjects (mean = %0.0f%%, range: %0.0f-%0.0f%%).'], ...
    nanmean(successratio*100), min(successratio*100), max(successratio*100))

for subj = 1:28
    % classification uses both mouse and key trials:
    allHealth = [health(:,:,subj); key_health(:,:,subj)];
    allTaste = [taste(:,:,subj); key_taste(:,:,subj)];
    
    % challenge trial: trials requiring self control 
    % false = control not required. true=control required
    challengeTrial = ...
        ((allHealth(:,1) > allHealth(:,2)) & ...
        (allTaste(:,1) < allTaste(:,2))) | ...
        ((allHealth(:,2) > allHealth(:,1)) & ...
        (allTaste(:,2) < allTaste(:,1)));
    
    % get reaction times in each trial type
    allRT = [RT; key_RT];
    rtSCReq(subj) = nanmean(allRT(challengeTrial,subj));
    rtSCNotReq(subj) = nanmean(allRT(~challengeTrial,subj));
    
end
[~,p,~,stats]=ttest(rtSCReq, rtSCNotReq);
sprintf(['There were no significant RT differences between challenge and '...
    'non-challenge trials (challenge mean = %0.0f ms; non-challenge mean = '...
    '%0.0f ms; t(%0.0f)=%0.2f, p=%0.2f, two-tailed)'], nanmean(rtSCReq*1000), ...
    nanmean(rtSCNotReq*1000), stats.df, stats.tstat, p)



%% Tastiness and healthfulness in the choice process

sprintf(['As hypothesized, mouse trajectories '...
    'were influenced by tastiness at significantly earlier time '...
    'windows (t = %0.0f) compared with healthfulness (t = %0.0f; '...
    'p < .05 threshold, one-tailed).'], sigTimes.tastehealth.all(1),...
    sigTimes.tastehealth.all(2))


% reported in paper:
sprintf(['We found that healthfulness never became a significant'...
    'influence on the trajectory for %0.0f%% of subjects, whereas'...
    'for tastiness this happened for no subjects.'],...
    100*(sum(isnan(sigTimes.tastehealth.bysubj(:,2)))./28))

% reported in paper:
[~,p,~,stats]=ttest(sigTimes.tastehealth.bysubj(:,1),sigTimes.tastehealth.bysubj(:,2),'tail','left')
sprintf(['Furthermore, as shown in Figure 4b, we also found that the mean earliest'...
    'time for a significant effect of healthfulness was later'...
    'than the mean earliest time for tastiness (mean difference'...
    '= %0.2f), t(%d) = %0.2f, p = %0.3f (one-tailed).'],...
    nanmean(sigTimes.tastehealth.bysubj(:,2)-sigTimes.tastehealth.bysubj(:,1)),...
    stats.df,stats.tstat,p)

% reported in paper:
sprintf(['Together, these results suggest that, on average, taste '...
    'information began to influence the choice process about '...
    '%0.0f%% earlier than health information.'],...
    nanmean(sigTimes.tastehealth.bysubj(:,2)-sigTimes.tastehealth.bysubj(:,1)))

% reported in paper:
for subj = 1:length(subjects)    
     mtRTrep(subj) = nanmean(nTPs(:,subj) * 10);
end
aveST = nanmean(sigTimes.tastehealth.bysubj)/101; % percent of trial
ST_perc_Diff = (aveST(2) - aveST(1)); % percent of trial difference
timeInMSforTasteAdvantage = nanmean(mtRTrep) * ST_perc_Diff
sprintf(['Given the average duration of the trials, this corresponded to an onset '...
    'of health-attribute processing by the choice circuitry'...
    'approximately %0.0f ms later than the onset for tastiness.'],...
    timeInMSforTasteAdvantage)



%% Dietary self-control and the speed at which tastiness and healthfulness are computed

% reported in paper:
sprintf(['In particular, in the high-self-control '...
    'group, the paths for tastiness and healthfulness were '...
    'quite similar and became significantly greater than zero '...
    'at approximately the same time (healthfulness: t = %0.0f; '...
    'tastiness: t = %0.0f). In contrast, for the low-self-control '...
    'group, the latency at which tastiness became significant '...
    'was similar to that of the high-self-control group (t = %0.0f), '...
    'but the latency for healthfulness occurred much later (t = %0.0f).'],...
    sigTimes.tastehealth.betterSC(2),sigTimes.tastehealth.betterSC(1),...
    sigTimes.tastehealth.worseSC(1),sigTimes.tastehealth.worseSC(2))

% reported in paper:
aLab={'taste','health'};
sLab={'higherSC','lowerSC'};
for aType = 1:2 % attribute
     for sType = 1:2 % higherSC or lowerSC SC
          stAve.(aLab{aType}).(sLab{sType}) = ...
              nanmean(sigTimes.tastehealth.bysubj(controlInd{sType},aType));
          stAll.(aLab{aType}).(sLab{sType}) = ...
              sigTimes.tastehealth.bysubj(controlInd{sType},aType);
     end
end
[~,pHigher,~,statsHigher]=ttest(stAll.taste.higherSC,stAll.health.higherSC,0.05,'left');
[~,pLower,~,statsLower]=ttest(stAll.taste.lowerSC,stAll.health.lowerSC,0.05,'left');
sprintf(['The normalized time at which tastiness and healthfulness became '...
    'significant did not differ significantly for high-self-control '...
    'subjects (mean healthfulness: t = %0.2f; mean tastiness: '...
    't = %0.2f; mean difference = %0.1f, t(%d) = %0.2f, p = %0.2f '...
    '(one-tailed), but they were significantly different in the '...
    'low-self-control group (mean healthfulness: t = %0.2f; '...
    'mean tastiness: t = %0.2f; mean difference = %0.0f), t(%d) = '...
    '%0.1f, p = %0.2f (one-tailed)'], stAve.health.higherSC,...
    stAve.taste.higherSC,nanmean(stAll.taste.higherSC-stAll.health.higherSC),...
    statsHigher.df, statsHigher.tstat, pHigher,...
    stAve.health.lowerSC, stAve.taste.lowerSC,...
    nanmean(stAll.taste.lowerSC-stAll.health.lowerSC),statsLower.df,...
    statsLower.tstat, pLower)


t=sigTimes.tastehealth.bysubj(:,1);
h=sigTimes.tastehealth.bysubj(:,2);
t(isnan(t))= 102;
h(isnan(h)) = 102;
stats = regstats(successratio,t-h);
varianceExplained=round(100*stats.rsquare);
sprintf(['In one case, we assumed that for the problem subjects, '...
    'healthfulness first became significant at t = 102, one time '...
    'point after the final time point, and estimated the regression '...
    'using all of the subjects (linear regression slope = '...
    '%0.3f, p < %0.4f, R2 = %0.2f).'],stats.beta(2),stats.tstat.pval(2),stats.rsquare) 

stats = regstats(successratio,sigTimes.tastehealth.bysubj(:,1)-sigTimes.tastehealth.bysubj(:,2));
sprintf(['In the other case, we simply excluded these subjects, carrying '...
    'out the regression using only the %0.1f%% of subjects for whom healthfulness'...
    'became significant during the trial. This yielded a similar'...
    'result (linear regression slope = %0.3f, p = %0.2f, R2 = %0.2f).'],...
    100*(1-sum(isnan(sigTimes.tastehealth.bysubj(:,2)))./28),...
    stats.beta(2), stats.tstat.pval(2), stats.rsquare)


% reported in paper:
stDiff = sigTimes.tastehealth.bysubj(:,1)-sigTimes.tastehealth.bysubj(:,2);
stats = regstats(stDiff,correctST.interDiff);
sprintf(['As shown in Figure 6b, we found that the differences '...
    'in earliest significant time identified with the previous '...
    'analysis were highly correlated with those '...
    'identified with this new method (R2 = %0.2f, p = %0.3f).'],...
    stats.rsquare,stats.tstat.pval(2))

% reported in paper:
stats=regstats(successratio,correctST.interDiff);
sprintf(['Likewise, the alternative measure of the relative earliest'...
    'times can still significantly predict a sizable fraction of'...
    'the individual differences in self-control (Fig. 6c; R2 ='...
    '%0.2f, p = %0.3f).'],stats.rsquare,stats.tstat.pval(2))
tasteAdvantagePercentPrediction_cubic = round(100*stats.rsquare);

%% Relative computation time and attribute decision weights

% compute decision weights across all trials
for subj=1:length(subjects)
     tD = [taste(:,2,subj)-taste(:,1,subj);key_taste(:,2,subj)-key_taste(:,1,subj)];
     hD = [health(:,2,subj)-health(:,1,subj);key_health(:,2,subj)-key_health(:,1,subj)];
     x = [tD hD];
     y = [choice(:,subj); key_choice(:,subj)]==2;
     [~,~,stats]=glmfit(x,y,'binomial','logit');
     tW(subj) = stats.beta(2);
     hW(subj) = stats.beta(3);
end
statsT = regstats(successratio,tW);
statsH = regstats(successratio,hW);

sprintf(['Both attributes were highly significant'...
    'and, on their own, explained a sizable fraction of'...
    'the individual differences in self-control (healthfulness:'...
    'p = %0.4f, R2 = %0.2f; tastiness: p = %0.4f, R2 = %0.2f).'],...
    statsH.fstat.pval, statsH.rsquare, statsT.fstat.pval, statsT.rsquare)

% reported in paper:
stats = regstats(tW-hW, sigTimes.tastehealth.bysubj(:,1)-sigTimes.tastehealth.bysubj(:,2));
sprintf(['To test this hypothesis, we regressed the individual estimates'...
    'of the final relative decision weight of healthfulness minus'...
    'tastiness on the computational advantage of tastiness, as '...
    'defined in the previous section. As shown in Figure 7b, we found that '...
    'the two variables had a significant '...
    'and sizable relation (slope = %0.2f, p = %0.3f, R2 = %0.3f).'],...
    stats.beta(2),stats.tstat.pval(2),stats.rsquare)


% reported in paper:
fid=fopen('mediation.txt','w');
mediationResults=mediationAnalysis(coef,sigTimes.tastehealth.bysubj,successratio,fid);
fclose(fid);
sprintf(['Using this method, we found that the when the final weight of '...
    'tastiness was included in the model, tastiness�s time to significance '...
    'was reduced by %0.3f%%, which made tastiness�s time to significance '...
    'nonsignificant for predicting SCSR (p = %0.3f).'],mediationResults.Taste.percChange,...
    mediationResults.Taste.pVal)

% reported in paper:
sprintf(['This was also true for the healthfulness'...
    'coefficient, which when added to the model reduced'...
    'path strength by %0.3f%%, making healthfulness�s time-tosignificance'...
    'nonsignificant for predicting SCSR (p = %0.3f).'],...
    mediationResults.Health.percChange,mediationResults.Health.pVal)



%% abstract

sprintf(['We found that, on average, tastiness was processed about %0.0f ms' ...
    'earlier than healthfulness during the choice process. We also found '...
    'that %0.0f%% to %0.0f%% of observed individual differences in self-control '...
    'ability could be explained by differences in the relative speed with '...
    'which tastiness and healthfulness were processed.\n'],...
    timeInMSforTasteAdvantage,tasteAdvantagePercentPrediction_cubic,...
    varianceExplained)


%% -----------------------------------------------------------------------
% FIGURES
% -----------------------------------------------------------------------

%% figure 2B: example trajectories

figure(fNo)
clf;
subj=1;
count = 1;
for trial = [11, 28]
    subplot(1,2,count); hold on; 
    
    % stimuli
    left_box = [162 918.5 510 656.5];
    right_box = [1170 918.5 1518 656.5];
    start_box_height = 65;
    start_box_width = 95;
    start_box = [screenDims(1)*.5-start_box_width screenDims(2)*.8-start_box_height ...
        screenDims(1)*.5+start_box_width screenDims(2)*.8+start_box_height];
    start_box([2 4]) = screenDims(2) - start_box([2 4]); %invert

    % mouse trajectory
    xCoordsRaw = xPos(trial,1:nTPs(trial,subj),subj);
    yCoordsRaw = yPos(trial,1:nTPs(trial,subj),subj);
    plot([left_box(1) left_box(3)],[left_box(4) left_box(4)],'k')
    plot([left_box(1) left_box(3)],[left_box(2) left_box(2)],'k')
    plot([left_box(1) left_box(1)],[left_box(2) left_box(4)],'k')
    plot([left_box(3) left_box(3)],[left_box(2) left_box(4)],'k')
    plot([right_box(1) right_box(3)],[right_box(4) right_box(4)],'k')
    plot([right_box(1) right_box(3)],[right_box(2) right_box(2)],'k')
    plot([right_box(1) right_box(1)],[right_box(2) right_box(4)],'k')
    plot([right_box(3) right_box(3)],[right_box(2) right_box(4)],'k')

    plot([start_box(1) start_box(3)],[start_box(4) start_box(4)],'k')
    plot([start_box(1) start_box(3)],[start_box(2) start_box(2)],'k')
    plot([start_box(1) start_box(1)],[start_box(2) start_box(4)],'k')
    plot([start_box(3) start_box(3)],[start_box(2) start_box(4)],'k')

    plot(xCoordsRaw,yCoordsRaw,'color','k','linewidth',2);
    xlim([0 screenDims(1)])
    ylim([0 screenDims(2)])
    xlabel('X Coord. (Pixels)','fontsize',fontsize)
    ylabel('Y Coord. (Pixels)','fontsize',fontsize)
    box on
    set(gca,'fontsize',fontsize)
    count=count+1;
    
end



box on
xticks = [0 800 1600];
set(gca,'fontsize',fontsize)
fNo = fNo+1;

%% figure 2C: mean paths

subj=1;
trajAllTrialsL = NaN(101,2,240);
trajAllTrialsR = NaN(101,2,240);
for trial = find(~isnan(choice(:,subj)))' % trial
        if choice(trial,subj)==1
             trajAllTrialsL(1:101,1:2,trial) = spatInterp{subj}(:,:,trial);
        elseif choice(trial,subj)==2
             trajAllTrialsR(1:101,1:2,trial) = spatInterp{subj}(:,:,trial);
        end
end

figure(fNo); hold on
title(['Subject ' num2str(subj) ', Mean Paths'],'fontsize',24)
plot([left_box(1) left_box(3)],[left_box(4) left_box(4)],'k')
plot([left_box(1) left_box(3)],[left_box(2) left_box(2)],'k')
plot([left_box(1) left_box(1)],[left_box(2) left_box(4)],'k')
plot([left_box(3) left_box(3)],[left_box(2) left_box(4)],'k')
plot([right_box(1) right_box(3)],[right_box(4) right_box(4)],'k')
plot([right_box(1) right_box(3)],[right_box(2) right_box(2)],'k')
plot([right_box(1) right_box(1)],[right_box(2) right_box(4)],'k')
plot([right_box(3) right_box(3)],[right_box(2) right_box(4)],'k')

plot([start_box(1) start_box(3)],[start_box(4) start_box(4)],'k')
plot([start_box(1) start_box(3)],[start_box(2) start_box(2)],'k')
plot([start_box(1) start_box(1)],[start_box(2) start_box(4)],'k')
plot([start_box(3) start_box(3)],[start_box(2) start_box(4)],'k')

plotTwoDimError(nanmean(trajAllTrialsL(:,1,:),3),nanmean(trajAllTrialsL(:,2,:),3),...
    nanstd(trajAllTrialsL(:,1,:),0,3)./sqrt(sum(choice(:,subj)==1)),...
    nanstd(trajAllTrialsL(:,2,:),0,3)./sqrt(sum(choice(:,subj)==1)),...
    {'lineColor','k','lineWidth',1,'plotType','shaded','patchSaturation',.3,'overlayLines',false});
plotTwoDimError(nanmean(trajAllTrialsR(:,1,:),3),nanmean(trajAllTrialsR(:,2,:),3),...
    nanstd(trajAllTrialsR(:,1,:),0,3)./sqrt(sum(choice(:,subj)==2)),...
    nanstd(trajAllTrialsR(:,2,:),0,3)./sqrt(sum(choice(:,subj)==2)),...
    {'lineColor','k','lineWidth',1,'plotType','shaded','patchSaturation',.3,'overlayLines',false});

box on
xlim([0 screenDims(1)])
ylim([0 screenDims(2)])
xlabel('X Coord. (Pixels)','fontsize',fontsize)
ylabel('Y Coord. (Pixels)','fontsize',fontsize)

box on
xticks = [0 800 1600];
set(gca,'fontsize',fontsize)
fNo = fNo+1;


%% figure 3A: psychometric curve


figure(fNo); hold on;
colors = [0 0 0; 0 0 0];
% mouse
[~,R,J,CovB,MSE] = nlinfit(predictorArray,outcomeArray_m,modelfun,beta0);
[yPredict,delta] = nlpredci(modelfun,-4:4,b_left_m,R,'Covar',CovB);

temp=shadedErrorBar(-4:4,100*modelfun(b_left_m,-4:4),100*delta,...
    {'color',colors(1,:),'linewidth',1.5},1);
key(1)=temp.mainLine;
% key
[~,R,J,CovB,MSE] = nlinfit(predictorArray,outcomeArray_k,modelfun,beta0);
[yPredict,delta] = nlpredci(modelfun,-4:4,b_left_k,R,'Covar',CovB);
temp=shadedErrorBar(-4:4,100*modelfun(b_left_k,-4:4),100*delta,...
    {'color',colors(2,:),'linewidth',1.5,'linestyle','--'},1);
key(2)=temp.mainLine;
set(gca,'XTick',-4:4)
set(gca,'YTick',0:20:100)
xlim([-4 4])
ylim([0 100])
legend(key,{'mouse','keyboard'},'location','northwest','fontsize',fontsize)
legend BOXOFF
ylabel('% Choose Left','fontsize',24);
xlabel('Left Liking - Right Liking','fontsize',24)
set(gca,'fontsize',fontsize)
fNo = fNo+1;




%% figure 3B: RT by difficulty
% subj 21 has several outlier RTs (was asking a question of experimenter)
 
colors = [0 0 0; 0 0 0];
clear key
figure(fNo);hold on;
temp=shadedErrorBar(0:4,nanmean(mouse_ABS.*1000,2),nanstd(mouse_ABS.*1000,0,2)./sqrt(28),...
    {'color',colors(1,:),'linewidth',1.5},1);
key(1)=temp.mainLine;
temp=shadedErrorBar(0:4,nanmean(keyboard_ABS.*1000,2),nanstd(keyboard_ABS.*1000,0,2)./sqrt(28),...
    {'color',colors(2,:),'linewidth',1.5,'linestyle','--'},1);
key(2)=temp.mainLine;
set(gca,'XTick',0:4)
xlim([-.5 4.5])
xlabel('Difficulty (liking difference)','fontsize',24)
ylabel('Mean (ms)','fontsize',24)
set(gca, 'fontsize', 20)
fNo = fNo+1;



%% figure 3C: liking timecourse regression graph (must run timepoint_regressions first)

timeArray = 1:101;
figure(fNo); hold on;
line([timeArray(1) timeArray(end)],[0 0],'color',[.4 .4 .4]) % zero-line
shadedErrorBar(timeArray,nanmean(coef.liking,2), ...
    nanstd(coef.liking')'/sqrt(28), {'Color',[0 0 0],'linewidth',1.5},1);
xlim([timeArray(1) timeArray(end)])
xlabel('Time normalized to 101 points','fontsize',24);
ylabel('Beta','fontsize',24)
set(gca,'XTick',0:20:100,'fontsize',fontsize)
fNo = fNo+1;


%% figure 3 D: control ratio histogram


figure(fNo); hold on;
hist(successratio);
h = get (gca, 'children');
h.FaceColor = [.6 .6 .6]; h.EdgeColor = 'k';
xlabel('SCSR','fontsize',24);
ylabel('Frequency','fontsize',24);
set(gca,'fontsize',fontsize)
fNo = fNo+1;

%% figure 4A: H & T TP regs

labels = {'taste' 'health'};
linestyles = {'-','-.'};
bwColors={[.3 .3 .3] [.3 .3 .3]};
% plot regression:
figure(fNo); hold on;
line([timeArray(1) timeArray(end)],[0 0],'color',[.4 .4 .4]) % zero-line
for r = 1:2
    temp = shadedErrorBar(timeArray,nanmean(coef.tastehealth(:,:,r),2), ...
        nanstd(coef.tastehealth(:,:,r),0,2)/sqrt(28), ...
        {'Color',bwColors{r},'linewidth',2,'linestyle',linestyles{r}},1);
    graphkey(r) = temp.mainLine;
end
for r = 1:2
    line([sigTimes.tastehealth.all(r) sigTimes.tastehealth.all(r)],...
        get(gca,'YLim'),'color',bwColors{r},'linestyle',linestyles{r},...
        'linewidth',2)
end
xlim([1 101]);ylim([-2 16])
set(gca,'fontsize',fontsize)
legend(graphkey,labels,'location','northwest','fontsize',fontsize);
legend BOXOFF
xlabel('Time normalized to 101 points','fontsize',24);
ylabel('Beta','fontsize',24)
fNo = fNo+1;

%% figure 4B: H T ST dist (approximately)

mx = nanmax(nanmax(sigTimes.tastehealth.bysubj));
mn = nanmin(nanmin(sigTimes.tastehealth.bysubj));
xvalues = linspace(0,100,11); 
xvalues2 = linspace(0,100,21);

figure(fNo); hold on;
histogram(correctST.timeP(:,1,:),xvalues, 'Normalization', 'pdf');
histogram(correctST.timeP(:,2,:),xvalues2, 'Normalization', 'pdf');
h = get (gca, 'children');
set(h(2),'FaceColor',[.2 .2 .2],'EdgeColor','k')
set(h(1),'FaceColor',[.6 .6 .6],'EdgeColor','k','LineStyle','-.')
alpha(h(1),.6)
graphkey = h;
legend(graphkey,{'health','taste'},'location','northwest','fontsize',fontsize)
legend BOXOFF
xlim([0,105])
xlabel('Significance time','fontsize',24);
ylabel('Frequency','fontsize',24);
set(gca,'fontsize',fontsize)
fNo = fNo+1;

%% figure 5 A: st by SC

% time course regression
clear labels
catCols{1} = {[.8 0 0],[.8 0 0]};% for taste
catCols{2} = {[0 0 .8],[0 0 .8]};% for health
linestyles{1} = {'-','--'}; % for taste
linestyles{2} = {'-','--'}; % for health
labels{1} = 'taste, better control';
labels{2} = 'taste, worse control';
labels{3} = 'health, better control';
labels{4} = 'health, worse control';
subjTypeNames = {'betterSC','worseSC'};
clear graphkey; graphkey_count = 1;
clear coefToPlotBetter coefToPlotWorse
figure(fNo); hold on;
line([timeArray(1) timeArray(end)],[0 0],'color',[.6 .6 .6]) % zero-line
for r = 1:2
    for subjType = 1:2
        coefToPlot = nanmean(coef.tastehealth(:,controlInd{subjType},r),2);
        stdForPlot = (nanstd(coef.tastehealth(:,controlInd{subjType},r),0,2)/sqrt(sum(controlInd{subjType})))';
        temp = shadedErrorBar(timeArray,coefToPlot, stdForPlot, ...
            {'Color',catCols{r}{subjType},'linewidth',2.5,'linestyle',linestyles{r}{subjType}},1);
        graphkey(graphkey_count) = temp.mainLine;
        graphkey_count = graphkey_count + 1;
    end
end
yLimits = get(gca,'YLim');
for r = 1:2
    for subjType = 1:2
        line([sigTimes.tastehealth.(subjTypeNames{subjType})(r) ...
            sigTimes.tastehealth.(subjTypeNames{subjType})(r)],...
            yLimits,'color',catCols{r}{subjType},...
            'linestyle',linestyles{r}{subjType},'linewidth',2.5);
    end
end
xlim([timeArray(1) timeArray(end)+1])
ylim([-2 17])
set(gca,'fontsize',fontsize)
xlabel('Time normalized to 101 points','fontsize',24);
ylabel('Beta','fontsize',24)
fNo = fNo+1;


%% figure 5B: significance time diff by control success


colorToUse='k';
clear graphkey
figure(fNo); hold on;
plot(sigTimes.tastehealth.bysubj(:,1)-sigTimes.tastehealth.bysubj(:,2),...
     successratio,'.','color',colorToUse,'markersize',40)
xPlotLocation = get(gca,'XLim');
stats = regstats(successratio,sigTimes.tastehealth.bysubj(:,1)-sigTimes.tastehealth.bysubj(:,2));
xvals = linspace(xPlotLocation(1),xPlotLocation(2));
yvals = (stats.beta(1)+stats.beta(2).*xvals);
plot(xvals,yvals,'color',colorToUse,'linewidth',1.5);
if sum(isnan(sigTimes.tastehealth.bysubj(:,1)-sigTimes.tastehealth.bysubj(:,2))) > 0
    graphkey = plot(ones(sum(isnan(sigTimes.tastehealth.bysubj(:,1)-sigTimes.tastehealth.bysubj(:,2))),1)*xPlotLocation(1),...
        successratio(isnan(sigTimes.tastehealth.bysubj(:,1)-sigTimes.tastehealth.bysubj(:,2))),...
        'marker','x','color',colorToUse,'markersize',15,'linewidth',2,'linestyle','none');
end
xlim([xvals(1) xvals(end)])
ylabel('SCSR','fontsize',24)
xlabel({'Significance time: Taste - health'},'fontsize',24)
set(gca,'fontsize',fontsize)
fNo = fNo+1;

%% figure 6A: percent max


figure(fNo); hold on;
linestyles = {'-','-.'};
clear graphkey
bwColors={[.3 .3 .3] [.3 .3 .3]};%bwColors={[1 0 0] [0 0 1]};
for r = 1:2
    y = nanmean(correctST.timeP(:,r,:),3);
    stdForPlot = nanstd(correctST.timeP(:,r,:),0,3)'/sqrt(28)';
    temp = shadedErrorBar(correctST.percents,y,stdForPlot, ...
        {'Color',bwColors{r},'linewidth',2.5,'linestyle',linestyles{r}},1);
    graphkey(r) = temp.mainLine;
end
legend(graphkey,{'taste','health'},'location','northwest','fontsize',fontsize)
legend BOXOFF
xlabel('Proportion of full attribute weighting','fontsize',24)
ylabel('Normalized time','fontsize',24)
set(gca,'fontsize',fontsize)
xlim([0 1]); ylim([35 95])
fNo = fNo+1;

%% figure 6B

y=sigTimes.tastehealth.bysubj(:,1)-sigTimes.tastehealth.bysubj(:,2);
x=correctST.intercept(1,:) - correctST.intercept(2,:);

figure(fNo); hold on;
plot(x,y,'ko','markersize',15,'linewidth',2)
xPlotLocation = get(gca,'XLim');
plot(x(isnan(y)),ones(sum(isnan(y)),1)*-50,'xk','markersize',15,'linewidth',2)
stats = regstats(y,x);
xvals = linspace(xPlotLocation(1),xPlotLocation(2));
yvals = (stats.beta(1)+stats.beta(2).*xvals);
plot(xvals,yvals,'color','k','linewidth',1.5);
xlim(xPlotLocation)
ylim([-50 40])
ylabel({'Significance time:','Taste-health'},'fontsize',24)
xlabel({'Intercept: Taste-health'},'fontsize',24)
set(gca,'fontsize',fontsize)
fNo = fNo+1;

%% figure 6C

y=successratio;
x=correctST.intercept(1,:) - correctST.intercept(2,:);

figure(fNo); hold on;
plot(x,y,'k^','markersize',15,'linewidth',2,'markerfacecolor','k')
stats = regstats(y,x);
xvals = linspace(xPlotLocation(1),xPlotLocation(2));
yvals = (stats.beta(1)+stats.beta(2).*xvals);
plot(xvals,yvals,'color','k','linewidth',1.5);
xlim([xvals(1) xvals(end)])
ylabel({'SCSR'},'fontsize',24)
xlabel({'Intercept: Taste-health'},'fontsize',24)
set(gca,'fontsize',fontsize)
fNo = fNo+1;

%% figure 7A: attribute weighting and SCSR

tW(tW>10) = NaN;
% plot it
thisHcolor=[0 0 0]; %thisHcolor=[0 0 1];
thisTcolor=[0 0 0]; %thisTcolor=[1 0 0];
figure(fNo); hold on;
plot(hW,successratio,'marker','s','linestyle','none','color',thisHcolor, ...
    'markerfacecolor',thisHcolor, 'markersize',15)
plot(tW,successratio,'marker','o','linestyle','none','color',thisTcolor, ...
    'linewidth',2, 'markersize',15)
xPlotLocation = get(gca,'XLim');
stats = regstats(successratio,tW);
xvals = linspace(xPlotLocation(1),xPlotLocation(2));
yvals = (stats.beta(1)+stats.beta(2).*xvals);
plot(xvals,yvals,'color',thisTcolor,'linewidth',1.5);
stats = regstats(successratio,hW);
xvals = linspace(xPlotLocation(1),xPlotLocation(2));
yvals = (stats.beta(1)+stats.beta(2).*xvals);
plot(xvals,yvals,'color',thisHcolor,'linewidth',1.5,'linestyle','--');
key(1) = plot(-500,-500,'marker','s','linestyle','--','color',thisHcolor,'linewidth',2,'markerfacecolor',thisHcolor,'markersize',10);
key(2) = plot(-500,-500,'marker','o','linestyle','-','color',thisTcolor,'linewidth',2,'markersize',10);
xlim(xPlotLocation)
ylim([0 max(successratio)])
set(gca,'fontsize',fontsize)
legend(key,{'Health','Taste'},'fontsize',fontsize)
legend BOXOFF
xlabel('Attribute weighting on choice','fontsize',24)
ylabel('SCSR','fontsize',24)
fNo = fNo+1;


%% fig 7B: decision weights by ST

y=tW-hW;
x=sigTimes.tastehealth.bysubj(:,1)-sigTimes.tastehealth.bysubj(:,2);
figure(fNo); hold on;
plot(x,y,'k.','markersize',40)
plot(ones(sum(isnan(x)),1)*-50,y(isnan(x)),'xk','markersize',15,'linewidth',2)
xPlotLocation = get(gca,'XLim');
set(gca,'fontsize',fontsize)
stats = regstats(y,x);
xvals = linspace(xPlotLocation(1),xPlotLocation(2));
yvals = (stats.beta(1)+stats.beta(2).*xvals);
plot(xvals,yvals,'color','k','linewidth',1.5);
xlim(xPlotLocation)
ylim([-.5,2])
xlabel({'Significance time: Taste-health'},'fontsize',24)
ylabel({'Attribute weighting:','Taste-health'},'fontsize',24)




end